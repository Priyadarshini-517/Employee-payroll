package com.epay.app;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.epay.app.modal.Admin;
import com.epay.app.modal.Attendance;
import com.epay.app.modal.Employee;
import com.epay.app.modal.Leaves;
import com.epay.app.modal.Salary;
import com.epay.app.modal.WorkSchedule;
import com.epay.app.repository.AdminRepository;
import com.epay.app.repository.AttendanceRepository;
import com.epay.app.repository.EmployeeRepository;
import com.epay.app.repository.LeavesRepository;
import com.epay.app.repository.SalaryRepository;
import com.epay.app.repository.WorkScheduleRepository;



	@SpringBootTest
	@TestMethodOrder(OrderAnnotation.class)
	public class AdminTest{
		
		@Autowired
		AdminRepository adrepo;

		@Test
		@Order(1)
		public void savepassword() {
			Admin c = new Admin();
			c.setId(1);
			c.setEmail("abc123@gmail.com");
			
			c.setPassword("teja");
			adrepo.save(c);
			assertNotNull(adrepo.findById(1).get());
		}
		
		@Autowired
		AttendanceRepository attrepo;
		
		@Test
		@Order(2)
		public void attendance() {
			Attendance a = new Attendance();
			a.setId(1);
			a.setEmpId(11);
			a.setEmail("abc@gmail.com");
			a.setAttendanceDate("12");
			a.setMonth("8");
			a.setYear("2019");
			a.setStatus("Present");
		    attrepo.save(a);
		    assertNotNull(attrepo.findById(1).get());
			
		}
		
		@Autowired
		EmployeeRepository emp;
		@Test
		@Order(3)
		public void employee() {
			Employee e = new Employee();
			e.setId(1L);
			e.setFname("Ram");
			e.setEmail("ram@gmail.com");
			e.setDepartment("Developing");
			e.setAge("21");
			e.setPassword("123456");
			e.setPhone("8754251683");
			e.setGender("male");
			e.setLname("kumar");
			e.setJoiningDate("12.1.2020");
			emp.save(e);
			assertNotNull(emp.findById(1L).get());
		}
		
		
		@Autowired
		LeavesRepository Leave;
		@Test
		@Order(4)
		public void leave() {
		Leaves l = new Leaves();
		l.setEmail("max@gmail.com");
		l.setEmpId(12);
		l.setId(1);
		l.setLeaveFrom("12.3.2020");
		l.setLeaveTo("16.3.2020");
		l.setReason("Not feel good");
		l.setStatus("not good");
		Leave.save(l);
		assertNotNull(Leave.findById(1).get());
		}
		
		@Autowired
		SalaryRepository sal;
		@Test
		@Order(5)
		public void salary() {
		 Salary s = new Salary();
		 s.setEmail("ha@gmail.com");
		 s.setEmpId(12);
		 s.setId(5);
		 s.setSalary("12000");
		 sal.save(s);
		 assertNotNull(sal.findById(1).get());
		}
		
		@Autowired
		WorkScheduleRepository work;
		@Test
		@Order(6)
		public void Working() {
			WorkSchedule w = new WorkSchedule();
			w.setEmail("helo@gmail.com");
			w.setEmpId(12);
			w.setEndDate("30.1.2020");
			w.setId(13);
			w.setStartDate("1.1.2020");
			w.setStatus("ok");
			w.setWorkDescription("new app using angular");
			w.setWorkTitle("Employee pay roll");
			work.save(w);
			assertNotNull(work.findById(1).get());
		}
		
		

	
	public void assertNotNull(Admin admin) {
	  System.out.println(adrepo.findAll());
		
	}

	public void assertNotNull(WorkSchedule workSchedule) {
		System.out.println(work.findAll());
		
	}

	public void assertNotNull(Salary salary) {
		System.out.println(sal.findAll());
		
	}

	public void assertNotNull(Leaves leaves) {
		System.out.println(Leave.findAll());
		
	}

	public void assertNotNull(Employee employee) {
	System.out.println(emp.findAll());
		
	}

	public void assertNotNull(Attendance attendance) {
		System.out.println(attrepo.findAll());
		
	}
	
	
	
	
	
	
}
