package com.epay.app.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.epay.app.modal.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Long> {

	boolean existsByEmail(String email);

	boolean existsByEmailAndPhone(String email, String phone);

	boolean existsByEmailOrPhone(String email, String phone);

	boolean existsByEmailAndPassword(String email, String password);

	Employee findByEmailAndPassword(String email, String password);

	@Modifying
	@Transactional
	@Query(value = "update employee E set E.password = ?3 where E.email = ?1 and E.phone= ?2", nativeQuery = true)
	void resetPassword(String email, String phone, String password);


 
}
