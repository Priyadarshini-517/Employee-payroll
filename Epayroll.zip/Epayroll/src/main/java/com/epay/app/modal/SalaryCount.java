package com.epay.app.modal;

public class SalaryCount {
	private int id;
	private String month;
	private String year;
	private String absent;
	private String present;
	private String days;

	public SalaryCount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalaryCount(int id, String month, String year, String absent, String present, String days) {
		super();
		this.id = id;
		this.month = month;
		this.year = year;
		this.absent = absent;
		this.present = present;
		this.days = days;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getAbsent() {
		return absent;
	}

	public void setAbsent(String absent) {
		this.absent = absent;
	}

	public String getPresent() {
		return present;
	}

	public void setPresent(String present) {
		this.present = present;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	@Override
	public String toString() {
		return "SalaryCount [id=" + id + ", month=" + month + ", year=" + year + ", absent=" + absent + ", present="
				+ present + ", days=" + days + "]";
	}

}
