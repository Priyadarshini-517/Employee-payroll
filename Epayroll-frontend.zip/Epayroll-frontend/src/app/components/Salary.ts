export interface Salary {
  id: number;
  email: string;
  salary: number;
}
