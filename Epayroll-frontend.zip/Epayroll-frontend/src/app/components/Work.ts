export interface Work {
  id: number;
  email: string;
  workTitle: string;
  workDescription: string;
  status: String;
  startDate: string;
  endDate: string;
}
