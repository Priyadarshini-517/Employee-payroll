import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListWssComponent } from './list-wss.component';

describe('ListWssComponent', () => {
  let component: ListWssComponent;
  let fixture: ComponentFixture<ListWssComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListWssComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListWssComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
