import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'rxjs';
import { Employee } from 'src/app/components/Employee';
import { Work } from 'src/app/components/Work';

@Component({
  selector: 'app-edit-wss',
  templateUrl: './edit-wss.component.html',
  styleUrls: ['./edit-wss.component.css'],
})
export class EditWssComponent implements OnInit {
  fetchedWork: Work[] = [];
  backendurl = 'http://localhost:8081/work';
  backendurl2 = 'http://localhost:8081/employee';

  WorkById: any;
  successStatus: string | undefined;
  isLoading = false;
  id: string | undefined;
  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id') as string;

    this.getWorkById(this.id);
    this.fetchEmployee();
  }

  fetchedEmployees: Employee[] = [];
  fetchEmployee() {
    this.http
      .get(this.backendurl2)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const EmployeeArray: Employee[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            EmployeeArray.push(x);
          }
          this.isLoading = false;
          return EmployeeArray;
        })
      )
      .subscribe((Employees) => {
        this.fetchedEmployees = Employees;
        console.log(Employees);
      });
  }

  getWorkById(id: string): void {
    this.http
      .get<Request>(this.backendurl + '/' + this.id)
      .subscribe((data) => {
        this.WorkById = data;
        console.log(this.WorkById);
      });
  }
  onUpdateSchedule(
    postData: {
      id: number;
      email: string;
      workTitle: string;
      workDescription: string;
      startDate: String;
      endDate: string;
      status: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.put(this.backendurl, postData).subscribe((responseData) => {
      console.log(responseData);
      alert('Work Schedule has been successfully modified');
      this.router.navigate(['admin/wss']);
    });
  }
}
