import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Leave } from '../../Leave';

@Component({
  selector: 'app-lms',
  templateUrl: './lms.component.html',
  styleUrls: ['./lms.component.css'],
})
export class LmsComponent implements OnInit {
  fetchedLeaves: Leave[] = [];
  backendurl = 'http://localhost:8081/leaves';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchLeaves();
  }
  fetchLeaves() {
    this.http
      .get(this.backendurl)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const leaveArray: Leave[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            leaveArray.push(x);
          }
          this.isLoading = false;
          return leaveArray;
        })
      )
      .subscribe((leaves) => {
        this.fetchedLeaves = leaves;
        console.log(leaves);
      });
  }

  onReject(leaveId: number) {
    this.http
      .put(this.backendurl + '/reject/' + leaveId, { responseType: 'text' })
      .subscribe((res) => {
        console.log(res);
        confirm('leave has been rejected successfully');
        {
          location.reload();
        }
      });
  }

  onApprove(leaveId: number) {
    this.http
      .put(this.backendurl + '/approve/' + leaveId, { responseType: 'text' })
      .subscribe((res) => {
        confirm('leave has been Approved successfully');
        {
          location.reload();
        }
      });
  }
}
