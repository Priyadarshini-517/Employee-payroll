import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Employee } from 'src/app/components/Employee';

@Component({
  selector: 'app-list-ems',
  templateUrl: './list-ems.component.html',
  styleUrls: ['./list-ems.component.css'],
})
export class ListEmsComponent implements OnInit {
  fetchedEmployees: Employee[] = [];
  backendurl = 'http://localhost:8081/employee';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchEmployee();
  }
  fetchEmployee() {
    this.http
      .get(this.backendurl)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const EmployeeArray: Employee[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            EmployeeArray.push(x);
          }
          this.isLoading = false;
          return EmployeeArray;
        })
      )
      .subscribe((Employees) => {
        this.fetchedEmployees = Employees;
        console.log(Employees);
      });
  }

  onDelete(empId: number) {
    this.http
      .delete(this.backendurl + '/' + empId, { responseType: 'text' })
      .subscribe((res) => {
        if (res) {
          confirm('Employee has been Deleted successfully');
          {
            location.reload();
          }
        } else {
          alert("Employee doesn't exists");
        }
      });
  }
}
