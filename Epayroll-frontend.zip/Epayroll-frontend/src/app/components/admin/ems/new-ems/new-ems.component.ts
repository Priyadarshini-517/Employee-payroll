import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-ems',
  templateUrl: './new-ems.component.html',
  styleUrls: ['./new-ems.component.css'],
})
export class NewEmsComponent implements OnInit {
  backendurl = 'http://localhost:8081/employee';
  successStatus: string | undefined;
  isLoading = false;

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {}

  onCreateEmployee(
    postData: {
      fname: string;
      lname: string;
      email: string;
      password: String;
      department: string;
      phone: string;
      gender: string;
      joiningDate: string;
      age: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.post(this.backendurl, postData).subscribe((responseData) => {
      console.log('log' + responseData);
      this.isLoading = false;

      if (responseData) {
        this.successStatus = 'Employee added successfully';
        confirm(this.successStatus);
        {
          this.router.navigate(['admin/ems']);
        }
      } else {
        alert('Employee with email or phone already exists');
      }
    });
  }
}
