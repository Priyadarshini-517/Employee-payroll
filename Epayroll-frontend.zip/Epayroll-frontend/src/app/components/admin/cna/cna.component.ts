import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { map } from 'rxjs';

@Component({
  selector: 'app-cna',
  templateUrl: './cna.component.html',
  styleUrls: ['./cna.component.css'],
})
export class CnaComponent implements OnInit {
  backendurl = 'http://localhost:8081/admin/signup';
  successStatus: string | undefined;
  isLoading = false;
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {}

  onCreateAdmin(
    postData: {
      email: string;
      password: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.post(this.backendurl, postData).subscribe((responseData) => {
      console.log('log' + responseData);
      this.isLoading = false;

      if (responseData) {
        this.successStatus = 'Admin added successfully';
        confirm(this.successStatus);
        {
          this.router.navigate(['admin']);
        }
      } else {
        alert('Admin with username already exists');
      }
    });
  }
}
