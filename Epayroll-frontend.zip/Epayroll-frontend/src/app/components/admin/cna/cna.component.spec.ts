import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CnaComponent } from './cna.component';

describe('CnaComponent', () => {
  let component: CnaComponent;
  let fixture: ComponentFixture<CnaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CnaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CnaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
