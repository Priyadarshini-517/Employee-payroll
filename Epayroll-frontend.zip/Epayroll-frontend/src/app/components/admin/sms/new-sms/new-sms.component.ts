import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Employee } from 'src/app/components/Employee';

@Component({
  selector: 'app-new-sms',
  templateUrl: './new-sms.component.html',
  styleUrls: ['./new-sms.component.css'],
})
export class NewSmsComponent implements OnInit {
  backendurl = 'http://localhost:8081/salary';
  backendurl2 = 'http://localhost:8081/employee';
  successStatus: string | undefined;
  isLoading = false;
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchEmployee();
  }

  fetchedEmployees: Employee[] = [];
  fetchEmployee() {
    this.http
      .get(this.backendurl2)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const EmployeeArray: Employee[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            EmployeeArray.push(x);
          }
          this.isLoading = false;
          return EmployeeArray;
        })
      )
      .subscribe((Employees) => {
        this.fetchedEmployees = Employees;
        console.log(Employees);
      });
  }
  onCreateSalary(
    postData: {
      email: string;
      salary: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.post(this.backendurl, postData).subscribe((responseData) => {
      console.log('log' + responseData);
      this.isLoading = false;

      if (responseData) {
        this.successStatus = 'Employee Salary added successfully';
        confirm(this.successStatus);
        {
          this.router.navigate(['admin/sms']);
        }
      } else {
        alert('Employee Salary already exists');
      }
    });
  }
}
