import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  backendurl = 'http://localhost:8081/admin/login';
  successStatus: string | undefined;
  isLoading = false;
  emailError = false;
  passwordError = false;
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    if (localStorage.getItem('adminLogin') === 'true') {
      this.router.navigate(['admin/dashboard']);
    }
  }

  onLogin(
    postData: {
      email: any;
      password: any;
    },
    form: NgForm
  ) {
    if (
      postData.email == '' ||
      postData.password == '' ||
      postData.email == null ||
      postData.password == null
    ) {
      if (postData.email == null || postData.email == '') {
        this.emailError = true;
        this.passwordError = false;
      }
      if (postData.password == null || postData.password == '') {
        this.passwordError = true;
        this.emailError = false;
      }
      if (
        ((postData.password == null || postData.password == '') &&
          postData.email == null) ||
        postData.email == ''
      ) {
        this.passwordError = true;
        this.emailError = true;
      }
    } else {
      this.http.post<any>(this.backendurl, postData).subscribe((res) => {
        console.log(res);
        if (res) {
          localStorage.setItem('adminLogin', 'true');
          this.router.navigate(['admin/dashboard']);
        } else {
          alert('Invalid Credentials');
          form.reset();
        }
      });
    }
  }
}
