import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'rxjs';
import { Employee } from 'src/app/components/Employee';

@Component({
  selector: 'app-edit-ams',
  templateUrl: './edit-ams.component.html',
  styleUrls: ['./edit-ams.component.css'],
})
export class EditAmsComponent implements OnInit {
  AttendanceById: any;
  id: string | undefined;
  fetchedEmployees: Employee[] = [];
  currentDate = new Date();
  backendurl = 'http://localhost:8081/attandance';
  backendurl2 = 'http://localhost:8081/employee';
  successStatus: string | undefined;
  isLoading = false;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.fetchEmployee();
    this.id = this.activatedRoute.snapshot.paramMap.get('id') as string;

    this.getAttendanceById();
  }

  fetchEmployee() {
    this.http
      .get(this.backendurl2)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const EmployeeArray: Employee[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            EmployeeArray.push(x);
          }
          this.isLoading = false;
          return EmployeeArray;
        })
      )
      .subscribe((Employees) => {
        this.fetchedEmployees = Employees;
        console.log(Employees);
      });
  }
  getAttendanceById(): void {
    this.http
      .get<Request>(this.backendurl + '/' + this.id)
      .subscribe((data) => {
        this.AttendanceById = data;
        console.log(data);
      });
  }
  onUpdateAttendance(
    postData: {
      id: number;
      email: string;
      attendanceDate: string;
      status: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.put(this.backendurl, postData).subscribe((responseData) => {
      console.log(responseData);
      if (responseData) {
        alert('Attendance has been successfully modified');
        this.router.navigate(['admin/ams']);
      }
    });
  }
}
