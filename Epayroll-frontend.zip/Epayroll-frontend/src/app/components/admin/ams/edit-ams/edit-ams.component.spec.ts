import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAmsComponent } from './edit-ams.component';

describe('EditAmsComponent', () => {
  let component: EditAmsComponent;
  let fixture: ComponentFixture<EditAmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditAmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
