import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-eregister',
  templateUrl: './eregister.component.html',
  styleUrls: ['./eregister.component.css'],
})
export class EregisterComponent implements OnInit {
  backendurl = 'http://localhost:8081/employee';
  successStatus: string | undefined;
  isLoading = false;

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    if (localStorage.getItem('employeeLogin') == 'true') {
      this.router.navigate(['employee/dashboard']);
    }
  }

  onCreateEmployee(
    postData: {
      fname: string;
      lname: string;
      email: string;
      password: String;
      department: string;
      phone: string;
      gender: string;
      joiningDate: string;
      age: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.post(this.backendurl, postData).subscribe((responseData) => {
      console.log('log' + responseData);
      this.isLoading = false;

      if (responseData) {
        this.successStatus = 'Signup Successfull';
        confirm(this.successStatus);
        {
          this.router.navigate(['']);
        }
      } else {
        alert('Employee with email or phone already exists');
      }
    });
  }
}
