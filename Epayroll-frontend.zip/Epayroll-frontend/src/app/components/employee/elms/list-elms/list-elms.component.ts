import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Leave } from 'src/app/components/Leave';

@Component({
  selector: 'app-list-elms',
  templateUrl: './list-elms.component.html',
  styleUrls: ['./list-elms.component.css'],
})
export class ListElmsComponent implements OnInit {
  fetchedLeaves: Leave[] = [];
  backendurl = 'http://localhost:8081/leaves';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchLeaves();
  }
  fetchLeaves() {
    this.http
      .get(this.backendurl + '/emp/' + localStorage.getItem('email'))
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const leaveArray: Leave[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            leaveArray.push(x);
          }
          this.isLoading = false;
          return leaveArray;
        })
      )
      .subscribe((leaves) => {
        this.fetchedLeaves = leaves;
        console.log(leaves);
      });
  }
}
