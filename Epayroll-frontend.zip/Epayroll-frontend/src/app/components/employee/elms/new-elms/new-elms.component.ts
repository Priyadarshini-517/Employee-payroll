import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-elms',
  templateUrl: './new-elms.component.html',
  styleUrls: ['./new-elms.component.css'],
})
export class NewElmsComponent implements OnInit {
  showError = false;
  backendurl = 'http://localhost:8081/leaves';
  successStatus: string | undefined;
  isLoading = false;
  email = localStorage.getItem('email');
  status = 'pending';
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {}
  onCreateLeave(
    postData: {
      email: string;
      leaveFrom: string;
      leaveTo: string;
      reason: String;
      status: string;
    },
    form: NgForm
  ) {
    if (form.valid) {
      this.isLoading = true;
      this.http.post(this.backendurl, postData).subscribe((responseData) => {
        console.log('log' + responseData);
        this.isLoading = false;

        if (responseData) {
          this.successStatus = 'Leave request added successfully';
          confirm(this.successStatus);
          {
            this.router.navigate(['employee/lms']);
          }
        }
      });
    } else {
      this.showError = true;
    }
  }
}
