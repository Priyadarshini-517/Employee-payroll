import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewElmsComponent } from './new-elms.component';

describe('NewElmsComponent', () => {
  let component: NewElmsComponent;
  let fixture: ComponentFixture<NewElmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewElmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewElmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
