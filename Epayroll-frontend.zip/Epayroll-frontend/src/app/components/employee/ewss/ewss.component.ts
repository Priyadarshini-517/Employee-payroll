import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Work } from 'src/app/components/Work';

@Component({
  selector: 'app-ewss',
  templateUrl: './ewss.component.html',
  styleUrls: ['./ewss.component.css'],
})
export class EwssComponent implements OnInit {
  fetchedWork: Work[] = [];
  backendurl = 'http://localhost:8081/work';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchWork();
  }
  fetchWork() {
    this.http
      .get(this.backendurl + '/emp/' + localStorage.getItem('email'))
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const WorkArray: Work[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            WorkArray.push(x);
          }
          this.isLoading = false;
          return WorkArray;
        })
      )
      .subscribe((Works) => {
        this.fetchedWork = Works;
        console.log(Works);
      });
  }
}
