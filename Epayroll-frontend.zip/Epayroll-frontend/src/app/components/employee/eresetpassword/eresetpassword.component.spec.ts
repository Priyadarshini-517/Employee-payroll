import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EresetpasswordComponent } from './eresetpassword.component';

describe('EresetpasswordComponent', () => {
  let component: EresetpasswordComponent;
  let fixture: ComponentFixture<EresetpasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EresetpasswordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EresetpasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
