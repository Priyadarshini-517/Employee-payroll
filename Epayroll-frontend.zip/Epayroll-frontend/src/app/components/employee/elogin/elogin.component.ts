import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-elogin',
  templateUrl: './elogin.component.html',
  styleUrls: ['./elogin.component.css'],
})
export class EloginComponent implements OnInit {
  showError = false;
  backendurl = 'http://localhost:8081/employee/login';
  successStatus: string | undefined;
  isLoading = false;
  emailError = false;
  passwordError = false;
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    if (localStorage.getItem('employeeLogin') === 'true') {
      this.router.navigate(['employee/dashboard']);
    }
  }

  onLogin(
    postData: {
      email: any;
      password: any;
    },
    form: NgForm
  ) {
    if (form.valid) {
      this.http.post<any>(this.backendurl, postData).subscribe((res) => {
        console.log(res);
        if (res) {
          localStorage.setItem('employeeLogin', 'true');
          localStorage.setItem('email', res.email);
          localStorage.setItem('id', res.id);
          console.log(res.email);
          this.router.navigate(['employee/dashboard']);
        } else {
          alert('Invalid Credentials');
          form.reset();
        }
      });
    } else {
      this.showError = true;
    }
  }
}
