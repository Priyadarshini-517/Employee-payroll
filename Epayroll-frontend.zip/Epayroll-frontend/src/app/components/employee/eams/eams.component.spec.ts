import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EamsComponent } from './eams.component';

describe('EamsComponent', () => {
  let component: EamsComponent;
  let fixture: ComponentFixture<EamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EamsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
