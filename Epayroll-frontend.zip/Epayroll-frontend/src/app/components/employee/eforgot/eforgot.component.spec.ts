import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EforgotComponent } from './eforgot.component';

describe('EforgotComponent', () => {
  let component: EforgotComponent;
  let fixture: ComponentFixture<EforgotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EforgotComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EforgotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
