import { NgModule } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/admin/login/login.component';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HttpClientModule } from '@angular/common/http';
import { ListEmsComponent } from './components/admin/ems/list-ems/list-ems.component';
import { NewEmsComponent } from './components/admin/ems/new-ems/new-ems.component';
import { EditEmsComponent } from './components/admin/ems/edit-ems/edit-ems.component';
import { ListWssComponent } from './components/admin/wss/list-wss/list-wss.component';
import { NewWssComponent } from './components/admin/wss/new-wss/new-wss.component';
import { EditWssComponent } from './components/admin/wss/edit-wss/edit-wss.component';
import { AddAmsComponent } from './components/admin/ams/add-ams/add-ams.component';
import { LmsComponent } from './components/admin/lms/lms.component';
import { ListSmsComponent } from './components/admin/sms/list-sms/list-sms.component';
import { NewSmsComponent } from './components/admin/sms/new-sms/new-sms.component';
import { EditSalaryComponent } from './components/admin/sms/edit-salary/edit-salary.component';
import { ListAmsComponent } from './components/admin/ams/list-ams/list-ams.component';
import { EloginComponent } from './components/employee/elogin/elogin.component';
import { EdashboardComponent } from './components/employee/edashboard/edashboard.component';
import { EheaderComponent } from './components/eheader/eheader.component';
import { EregisterComponent } from './components/employee/eregister/eregister.component';
import { EforgotComponent } from './components/employee/eforgot/eforgot.component';
import { EProfileComponent } from './components/employee/e-profile/e-profile.component';
import { EwssComponent } from './components/employee/ewss/ewss.component';
import { EamsComponent } from './components/employee/eams/eams.component';
import { ListElmsComponent } from './components/employee/elms/list-elms/list-elms.component';
import { NewElmsComponent } from './components/employee/elms/new-elms/new-elms.component';
import { ListEsmsComponent } from './components/employee/esms/list-esms/list-esms.component';
import { EresetpasswordComponent } from './components/employee/eresetpassword/eresetpassword.component';
import { CnaComponent } from './components/admin/cna/cna.component';
import { EditAmsComponent } from './components/admin/ams/edit-ams/edit-ams.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    ListEmsComponent,
    NewEmsComponent,
    EditEmsComponent,
    ListWssComponent,
    NewWssComponent,
    EditWssComponent,
    AddAmsComponent,
    LmsComponent,
    ListSmsComponent,
    NewSmsComponent,
    EditSalaryComponent,
    ListAmsComponent,
    EloginComponent,
    EdashboardComponent,
    EheaderComponent,
    EregisterComponent,
    EforgotComponent,
    EProfileComponent,
    EwssComponent,
    EamsComponent,

    ListElmsComponent,
    NewElmsComponent,
    ListEsmsComponent,
    EresetpasswordComponent,
    CnaComponent,
    EditAmsComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
